package com.stagesound.app.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay

/** Fades + springs a block in, one after another. */
@Composable
fun Staggered(index: Int, content: @Composable () -> Unit) {
    var visible by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        delay(70L * index)
        visible = true
    }
    AnimatedVisibility(
        visible = visible,
        enter = fadeIn(spring(stiffness = Spring.StiffnessLow)) +
            slideInVertically(
                spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow),
            ) { it / 3 },
    ) {
        content()
    }
}

/** Squishy press animation. */
@Composable
fun Modifier.bouncyClick(onClick: () -> Unit): Modifier {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val s by animateFloatAsState(
        targetValue = if (pressed) 0.93f else 1f,
        animationSpec = spring(dampingRatio = 0.35f, stiffness = 500f),
        label = "press",
    )
    return this
        .graphicsLayer {
            scaleX = s
            scaleY = s
        }
        .clickable(interactionSource = src, indication = null, onClick = onClick)
}

@Composable
fun Header(title: String, subtitle: String) {
    Column(Modifier.padding(top = 8.dp)) {
        Text(
            title,
            style = MaterialTheme.typography.displaySmall,
            fontWeight = FontWeight.ExtraBold,
            color = MaterialTheme.colorScheme.onSurface,
        )
        Text(
            subtitle,
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
fun SectionCard(
    title: String,
    icon: ImageVector? = null,
    modifier: Modifier = Modifier,
    content: @Composable ColumnScope.() -> Unit,
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(32.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer),
    ) {
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                if (icon != null) {
                    Box(
                        Modifier
                            .size(36.dp)
                            .graphicsLayer { },
                        contentAlignment = Alignment.Center,
                    ) {
                        Icon(icon, null, tint = MaterialTheme.colorScheme.primary)
                    }
                }
                Text(
                    title,
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                )
            }
            content()
        }
    }
}

@Composable
fun LabeledSlider(
    label: String,
    valueText: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    onChange: (Float) -> Unit,
) {
    Column {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, style = MaterialTheme.typography.titleMedium)
            Text(
                valueText,
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.primary,
                fontWeight = FontWeight.Bold,
            )
        }
        Slider(value = value, onValueChange = onChange, valueRange = range)
    }
}

/** The big animated power button: rotating ring, breathing glow and sound waves when on. */
@Composable
fun AtmosOrb(active: Boolean, onToggle: () -> Unit) {
    val inf = rememberInfiniteTransition(label = "orb")
    val rot by inf.animateFloat(
        0f, 360f, infiniteRepeatable(tween(7000, easing = LinearEasing)), label = "rot",
    )
    val wave by inf.animateFloat(
        0f, 1f, infiniteRepeatable(tween(2800, easing = LinearEasing)), label = "wave",
    )
    val breathe by inf.animateFloat(
        0.96f, 1.05f,
        infiniteRepeatable(tween(1900, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "breathe",
    )
    val amount by animateFloatAsState(
        if (active) 1f else 0f,
        spring(dampingRatio = 0.5f, stiffness = Spring.StiffnessLow),
        label = "amount",
    )
    val iconScale by animateFloatAsState(
        if (active) 1.15f else 0.9f,
        spring(dampingRatio = 0.3f, stiffness = 300f),
        label = "iconScale",
    )
    val cs = MaterialTheme.colorScheme
    val c1 = cs.primary
    val c2 = cs.tertiary
    val c3 = cs.secondary
    val off = cs.outlineVariant
    val discOff = cs.surfaceContainerHighest
    val discOn = cs.primaryContainer

    Box(
        Modifier
            .size(270.dp)
            .bouncyClick(onToggle),
        contentAlignment = Alignment.Center,
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val center = Offset(size.width / 2f, size.height / 2f)
            val base = size.minDimension * 0.28f

            for (k in 0 until 3) {
                val p = (wave + k / 3f) % 1f
                drawCircle(
                    color = c1.copy(alpha = (1f - p) * 0.4f * amount),
                    radius = base * (1f + 0.85f * p),
                    center = center,
                    style = Stroke(width = 3.dp.toPx()),
                )
            }
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(c1.copy(alpha = 0.5f * amount), Color.Transparent),
                    center = center,
                    radius = base * 1.9f,
                ),
                radius = base * 1.9f,
                center = center,
            )
            rotate(rot, center) {
                drawCircle(
                    brush = Brush.sweepGradient(
                        colors = listOf(
                            lerp(off, c1, amount), lerp(off, c2, amount),
                            lerp(off, c3, amount), lerp(off, c1, amount),
                        ),
                        center = center,
                    ),
                    radius = base * breathe,
                    center = center,
                    style = Stroke(width = (4.dp.toPx() + 6.dp.toPx() * amount)),
                )
            }
            drawCircle(
                color = lerp(discOff, discOn, amount),
                radius = base * 0.86f * breathe,
                center = center,
            )
        }
        Icon(
            Icons.Filled.GraphicEq,
            contentDescription = "Toggle",
            tint = lerp(cs.onSurfaceVariant, cs.onPrimaryContainer, amount),
            modifier = Modifier
                .size(60.dp)
                .scale(iconScale),
        )
    }
}

@Composable
fun SpacerH(h: Int) = Spacer(Modifier.height(h.dp))
