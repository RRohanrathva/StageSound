package com.stagesound.app.data

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update

enum class Mode { NORMAL, SHIZUKU }

val EQ_FREQS = floatArrayOf(31f, 62f, 125f, 250f, 500f, 1000f, 2000f, 4000f, 8000f, 16000f)
val EQ_LABELS = listOf("31", "62", "125", "250", "500", "1k", "2k", "4k", "8k", "16k")

data class Preset(
    val name: String,
    val spatial: Int,
    val bass: Int,
    val loudness: Int,
    val eq: List<Float>,
)

val PRESETS = listOf(
    Preset("Atmos Movie", 78, 40, 25, listOf(3f, 2f, 1f, 0f, -1f, 0f, 1f, 3f, 3f, 2f)),
    Preset("Atmos Music", 62, 35, 15, listOf(2f, 2f, 1f, 0f, 0f, 1f, 1f, 2f, 3f, 2f)),
    Preset("Dialogue", 35, 10, 20, listOf(-2f, -2f, -1f, 0f, 2f, 3f, 3f, 2f, 0f, -1f)),
    Preset("Bass Punch", 50, 70, 25, listOf(5f, 5f, 3f, 1f, 0f, 0f, 0f, 0f, 1f, 1f)),
    Preset("Gaming", 85, 30, 30, listOf(2f, 1f, 0f, -1f, 0f, 2f, 3f, 4f, 3f, 1f)),
    Preset("Flat", 0, 0, 0, List(10) { 0f }),
)

data class SoundSettings(
    val enabled: Boolean = false,
    val preset: String = "Atmos Movie",
    val spatial: Int = 78,
    val bass: Int = 40,
    val loudness: Int = 25,
    val balance: Int = 0,
    val limiter: Boolean = true,
    val virtMode: Int = 0, // 0 auto, 1 speaker (transaural), 2 headphones (binaural)
    val eq: List<Float> = PRESETS[0].eq,
    val mode: Mode = Mode.NORMAL,
    val autoStart: Boolean = false,
    val includeGlobal: Boolean = true,
    val scanSeconds: Int = 2,
)

data class TrackedSession(val id: Int, val pkg: String?, val source: String)

object EngineState {
    val sessions = MutableStateFlow<List<TrackedSession>>(emptyList())
    val running = MutableStateFlow(false)
}

class SettingsStore(ctx: Context) {
    private val sp = ctx.getSharedPreferences("stage_sound", Context.MODE_PRIVATE)
    val flow = MutableStateFlow(load())

    private fun load(): SoundSettings {
        val d = SoundSettings()
        val eq = sp.getString("eq", null)
            ?.split(",")
            ?.mapNotNull { it.toFloatOrNull() }
            ?.takeIf { it.size == 10 } ?: d.eq
        val mode = runCatching { Mode.valueOf(sp.getString("mode", "NORMAL") ?: "NORMAL") }
            .getOrDefault(Mode.NORMAL)
        return SoundSettings(
            enabled = sp.getBoolean("enabled", d.enabled),
            preset = sp.getString("preset", d.preset) ?: d.preset,
            spatial = sp.getInt("spatial", d.spatial),
            bass = sp.getInt("bass", d.bass),
            loudness = sp.getInt("loudness", d.loudness),
            balance = sp.getInt("balance", d.balance),
            limiter = sp.getBoolean("limiter", d.limiter),
            virtMode = sp.getInt("virtMode", d.virtMode),
            eq = eq,
            mode = mode,
            autoStart = sp.getBoolean("autoStart", d.autoStart),
            includeGlobal = sp.getBoolean("includeGlobal", d.includeGlobal),
            scanSeconds = sp.getInt("scanSeconds", d.scanSeconds),
        )
    }

    private fun save(s: SoundSettings) {
        sp.edit()
            .putBoolean("enabled", s.enabled)
            .putString("preset", s.preset)
            .putInt("spatial", s.spatial)
            .putInt("bass", s.bass)
            .putInt("loudness", s.loudness)
            .putInt("balance", s.balance)
            .putBoolean("limiter", s.limiter)
            .putInt("virtMode", s.virtMode)
            .putString("eq", s.eq.joinToString(","))
            .putString("mode", s.mode.name)
            .putBoolean("autoStart", s.autoStart)
            .putBoolean("includeGlobal", s.includeGlobal)
            .putInt("scanSeconds", s.scanSeconds)
            .apply()
    }

    fun update(block: (SoundSettings) -> SoundSettings) {
        flow.update(block)
        save(flow.value)
    }

    fun applyPreset(p: Preset) = update {
        it.copy(preset = p.name, spatial = p.spatial, bass = p.bass, loudness = p.loudness, eq = p.eq)
    }
}
