package com.stagesound.app.engine

import android.media.audiofx.AudioEffect
import android.media.audiofx.BassBoost
import android.media.audiofx.DynamicsProcessing
import android.media.audiofx.Equalizer
import android.media.audiofx.LoudnessEnhancer
import android.media.audiofx.Virtualizer
import android.os.Build
import com.stagesound.app.data.EQ_FREQS
import com.stagesound.app.data.EngineState
import com.stagesound.app.data.SoundSettings
import com.stagesound.app.data.TrackedSession
import kotlin.math.abs
import kotlin.math.max

/**
 * Holds one chain of audio effects per audio session and keeps them in sync with the settings.
 * Chain = Virtualizer (spatial / stereo widening) + BassBoost + LoudnessEnhancer +
 * DynamicsProcessing (10-band EQ, limiter, balance). Equalizer is used if DynamicsProcessing is missing.
 */
class AudioEngine {

    private class Chain(val session: Int) {
        var virt: Virtualizer? = null
        var bass: BassBoost? = null
        var loud: LoudnessEnhancer? = null
        var dp: DynamicsProcessing? = null
        var eq: Equalizer? = null

        fun release() {
            listOf<AudioEffect?>(virt, bass, loud, dp, eq).forEach { runCatching { it?.release() } }
        }
    }

    private class Tracked(val id: Int, var pkg: String?, val source: String, var miss: Int = 0)

    private val chains = HashMap<Int, Chain>()
    private val tracked = LinkedHashMap<Int, Tracked>()
    private var settings = SoundSettings()
    private var globalTried = false
    private val maxChains = 14

    @Synchronized
    fun apply(s: SoundSettings) {
        settings = s
        if (s.enabled && s.includeGlobal) {
            if (!globalTried) {
                globalTried = true
                attachInternal(0, "System mix (session 0)", "GLOBAL")
            }
        } else {
            globalTried = false
            if (chains.containsKey(0)) detachInternal(0)
        }
        chains.values.forEach { applyChain(it) }
        publish()
    }

    @Synchronized
    fun attach(id: Int, pkg: String?, source: String): Boolean {
        val ok = attachInternal(id, pkg, source)
        publish()
        return ok
    }

    @Synchronized
    fun detach(id: Int) {
        detachInternal(id)
        publish()
    }

    @Synchronized
    fun syncScan(found: List<Pair<Int, String?>>) {
        val ids = found.map { it.first }.toSet()
        for ((id, pkg) in found) {
            val t = tracked[id]
            if (t == null) attachInternal(id, pkg, "SCAN") else {
                t.miss = 0
                if (t.pkg == null) t.pkg = pkg
            }
        }
        val gone = tracked.values.filter { it.source == "SCAN" && it.id !in ids }
        for (t in gone) {
            t.miss++
            if (t.miss >= 3) detachInternal(t.id)
        }
        publish()
    }

    @Synchronized
    fun releaseAll() {
        chains.values.forEach { it.release() }
        chains.clear()
        tracked.clear()
        globalTried = false
        publish()
    }

    private fun publish() {
        EngineState.sessions.value = tracked.values.map { TrackedSession(it.id, it.pkg, it.source) }
    }

    private fun attachInternal(id: Int, pkg: String?, source: String): Boolean {
        if (chains.containsKey(id)) {
            tracked[id]?.let { if (pkg != null && it.pkg == null) it.pkg = pkg }
            return true
        }
        if (chains.size >= maxChains) return false
        val c = Chain(id)
        c.virt = runCatching { Virtualizer(0, id) }.getOrNull()
        c.bass = runCatching { BassBoost(0, id) }.getOrNull()
        c.loud = runCatching { LoudnessEnhancer(id) }.getOrNull()
        c.dp = if (Build.VERSION.SDK_INT >= 28) runCatching { makeDp(id) }.getOrNull() else null
        if (c.dp == null) c.eq = runCatching { Equalizer(0, id) }.getOrNull()
        if (c.virt == null && c.bass == null && c.loud == null && c.dp == null && c.eq == null) return false
        chains[id] = c
        tracked[id] = Tracked(id, pkg, source)
        applyChain(c)
        return true
    }

    private fun detachInternal(id: Int) {
        chains.remove(id)?.release()
        tracked.remove(id)
    }

    private fun makeDp(session: Int): DynamicsProcessing {
        val cfg = DynamicsProcessing.Config.Builder(
            DynamicsProcessing.VARIANT_FAVOR_FREQUENCY_RESOLUTION,
            2, true, 10, false, 0, false, 0, true,
        ).build()
        return DynamicsProcessing(0, session, cfg)
    }

    private inline fun safe(block: () -> Unit) {
        try {
            block()
        } catch (_: Throwable) {
        }
    }

    private fun applyChain(c: Chain) {
        val s = settings
        val on = s.enabled

        c.virt?.let { v ->
            safe { v.setStrength((s.spatial * 10).coerceIn(0, 1000).toShort()) }
            if (Build.VERSION.SDK_INT >= 32) {
                safe {
                    val mode = when (s.virtMode) {
                        1 -> Virtualizer.VIRTUALIZATION_MODE_TRANSAURAL
                        2 -> Virtualizer.VIRTUALIZATION_MODE_BINAURAL
                        else -> Virtualizer.VIRTUALIZATION_MODE_AUTO
                    }
                    v.forceVirtualizationMode(mode)
                }
            }
            safe { v.setEnabled(on && s.spatial > 0) }
        }

        c.bass?.let { b ->
            safe { b.setStrength((s.bass * 10).coerceIn(0, 1000).toShort()) }
            safe { b.setEnabled(on && s.bass > 0) }
        }

        c.loud?.let { l ->
            safe { l.setTargetGain(s.loudness * 15) }
            safe { l.setEnabled(on && s.loudness > 0) }
        }

        c.dp?.let { dp ->
            safe {
                val eq = DynamicsProcessing.Eq(true, true, 10)
                s.eq.forEachIndexed { i, g -> eq.setBand(i, DynamicsProcessing.EqBand(true, EQ_FREQS[i], g)) }
                dp.setPreEqAllChannelsTo(eq)
            }
            safe {
                dp.setLimiterAllChannelsTo(
                    DynamicsProcessing.Limiter(true, s.limiter, 0, 1f, 60f, 10f, -2f, 0f),
                )
            }
            safe {
                val comp = -(max(0f, s.eq.max()) * 0.6f)
                val left = comp + if (s.balance > 0) -(s.balance / 100f * 12f) else 0f
                val right = comp + if (s.balance < 0) -(-s.balance / 100f * 12f) else 0f
                dp.setInputGainbyChannel(0, left)
                dp.setInputGainbyChannel(1, right)
            }
            safe { dp.setEnabled(on) }
        }

        c.eq?.let { e ->
            safe {
                val range = e.bandLevelRange
                val n = e.numberOfBands.toInt()
                for (b in 0 until n) {
                    val hz = e.getCenterFreq(b.toShort()) / 1000f
                    var best = 0
                    for (i in EQ_FREQS.indices) if (abs(EQ_FREQS[i] - hz) < abs(EQ_FREQS[best] - hz)) best = i
                    val mb = (s.eq[best] * 100).toInt().coerceIn(range[0].toInt(), range[1].toInt())
                    e.setBandLevel(b.toShort(), mb.toShort())
                }
            }
            safe { e.setEnabled(on) }
        }
    }
}
