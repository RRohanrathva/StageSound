package com.stagesound.app

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import com.stagesound.app.engine.EngineService
import com.stagesound.app.engine.ShizukuBridge
import com.stagesound.app.ui.StageApp
import com.stagesound.app.ui.StageTheme

class MainActivity : ComponentActivity() {

    private val notifPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val store = (application as StageApplication).store
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED
        ) {
            notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        if (store.flow.value.enabled) runCatching { EngineService.start(this) }

        setContent {
            StageTheme {
                StageApp(store)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        ShizukuBridge.refresh()
    }
}
