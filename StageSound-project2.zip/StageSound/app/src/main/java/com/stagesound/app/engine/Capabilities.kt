package com.stagesound.app.engine

import android.media.audiofx.AudioEffect
import java.util.UUID

object Capabilities {
    private val dynamicsProcessing = UUID.fromString("7261676f-6d75-7369-6364-28e2fd3ac39e")

    /** Which effect types this phone's audio HAL really offers. */
    fun query(): List<Pair<String, Boolean>> {
        val types = runCatching { AudioEffect.queryEffects()?.map { it.type } ?: emptyList() }
            .getOrDefault(emptyList())
        fun has(u: UUID) = types.contains(u)
        return listOf(
            "Virtualizer" to has(AudioEffect.EFFECT_TYPE_VIRTUALIZER),
            "Bass boost" to has(AudioEffect.EFFECT_TYPE_BASS_BOOST),
            "Loudness" to has(AudioEffect.EFFECT_TYPE_LOUDNESS_ENHANCER),
            "Equalizer" to has(AudioEffect.EFFECT_TYPE_EQUALIZER),
            "Dynamics (10-band EQ)" to has(dynamicsProcessing),
        )
    }
}
