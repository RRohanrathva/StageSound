package com.stagesound.app.ui

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.ExperimentalAnimationApi
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Headphones
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Speaker
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.AssistChip
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.stagesound.app.data.EngineState
import com.stagesound.app.data.Mode
import com.stagesound.app.data.PRESETS
import com.stagesound.app.data.SettingsStore
import com.stagesound.app.engine.EngineService
import com.stagesound.app.engine.SpeakerDemo
import kotlinx.coroutines.launch

@OptIn(ExperimentalAnimationApi::class, ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(store: SettingsStore) {
    val ctx = LocalContext.current
    val s by store.flow.collectAsStateWithLifecycle()
    val sessions by EngineState.sessions.collectAsStateWithLifecycle()
    val scope = rememberCoroutineScope()
    var demoRunning by remember { mutableStateOf(false) }

    fun toggle() {
        val next = !s.enabled
        store.update { it.copy(enabled = next) }
        if (next) EngineService.start(ctx) else EngineService.stop(ctx)
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        item {
            Staggered(0) { Header("Stage Sound", "Atmos-style wide stereo for both speakers") }
        }

        item {
            Staggered(1) {
                Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                    AtmosOrb(active = s.enabled, onToggle = ::toggle)
                    AnimatedContent(
                        targetState = s.enabled,
                        transitionSpec = {
                            (fadeIn(spring(stiffness = Spring.StiffnessLow)) + scaleIn(initialScale = 0.8f)) togetherWith
                                (fadeOut() + scaleOut(targetScale = 0.8f))
                        },
                        label = "status",
                    ) { on ->
                        Text(
                            if (on) "Spatial sound is ON" else "Tap the orb to turn on",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = if (on) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    Row(
                        Modifier.padding(top = 10.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        AssistChip(
                            onClick = {},
                            label = { Text(if (s.mode == Mode.SHIZUKU) "Shizuku mode" else "Normal mode") },
                            leadingIcon = { Icon(Icons.Filled.Bolt, null, Modifier.size(18.dp)) },
                        )
                        AssistChip(
                            onClick = {},
                            label = { Text("${sessions.size} session(s)") },
                            leadingIcon = { Icon(Icons.Filled.Speaker, null, Modifier.size(18.dp)) },
                        )
                    }
                }
            }
        }

        item {
            Staggered(2) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Sound mode", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(PRESETS) { p ->
                            FilterChip(
                                selected = s.preset == p.name,
                                onClick = { store.applyPreset(p) },
                                label = { Text(p.name) },
                            )
                        }
                    }
                }
            }
        }

        item {
            Staggered(3) {
                SectionCard("Spatial sound", Icons.Filled.Speaker) {
                    LabeledSlider(
                        label = "Stage width (Atmos-style)",
                        valueText = "${s.spatial}%",
                        value = s.spatial.toFloat(),
                        range = 0f..100f,
                    ) { v -> store.update { it.copy(spatial = v.toInt(), preset = "Custom") } }

                    Text("Virtualizer target", style = MaterialTheme.typography.labelLarge)
                    val labels = listOf("Auto", "Speakers", "Headphones")
                    SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
                        labels.forEachIndexed { i, l ->
                            SegmentedButton(
                                selected = s.virtMode == i,
                                onClick = { store.update { it.copy(virtMode = i) } },
                                shape = SegmentedButtonDefaults.itemShape(i, labels.size),
                                label = { Text(l) },
                            )
                        }
                    }
                }
            }
        }

        item {
            Staggered(4) {
                SectionCard("Tone & level", Icons.Filled.Tune) {
                    LabeledSlider(
                        label = "Bass",
                        valueText = "${s.bass}%",
                        value = s.bass.toFloat(),
                        range = 0f..100f,
                    ) { v -> store.update { it.copy(bass = v.toInt(), preset = "Custom") } }

                    LabeledSlider(
                        label = "Loudness",
                        valueText = "+${s.loudness * 15 / 100} dB",
                        value = s.loudness.toFloat(),
                        range = 0f..100f,
                    ) { v -> store.update { it.copy(loudness = v.toInt(), preset = "Custom") } }

                    LabeledSlider(
                        label = "Balance",
                        valueText = when {
                            s.balance == 0 -> "Center"
                            s.balance < 0 -> "L ${-s.balance}"
                            else -> "R ${s.balance}"
                        },
                        value = s.balance.toFloat(),
                        range = -100f..100f,
                    ) { v ->
                        val r = v.toInt()
                        store.update { it.copy(balance = if (kotlin.math.abs(r) < 4) 0 else r) }
                    }

                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Column {
                            Text("Safety limiter", style = MaterialTheme.typography.titleMedium)
                            Text(
                                "Prevents distortion at high volume",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                        Switch(checked = s.limiter, onCheckedChange = { c -> store.update { it.copy(limiter = c) } })
                    }
                }
            }
        }

        item {
            Staggered(5) {
                SectionCard("Hear the difference", Icons.Filled.Headphones) {
                    Text(
                        "Plays a short left → right → sweeping tone. Turn the orb on/off and play again to compare.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    FilledTonalButton(
                        onClick = {
                            if (!demoRunning) scope.launch {
                                demoRunning = true
                                runCatching { SpeakerDemo.play() }
                                demoRunning = false
                            }
                        },
                        enabled = !demoRunning,
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Icon(Icons.Filled.PlayArrow, null)
                        Text(if (demoRunning) "  Playing…" else "  Play stereo test")
                    }
                }
            }
        }
    }
}
