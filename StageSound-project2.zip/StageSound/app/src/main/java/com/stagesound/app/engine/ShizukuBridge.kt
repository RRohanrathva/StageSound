package com.stagesound.app.engine

import android.Manifest
import android.content.ComponentName
import android.content.Context
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.os.IBinder
import com.stagesound.app.IShellService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku

data class ShizukuStatus(
    val running: Boolean = false,
    val granted: Boolean = false,
    val serviceConnected: Boolean = false,
    val dumpGranted: Boolean = false,
    val log: String = "",
)

object ShizukuBridge {
    val status = MutableStateFlow(ShizukuStatus())

    private var app: Context? = null
    private var service: IShellService? = null

    private val conn = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
            service = if (binder != null && binder.pingBinder()) IShellService.Stub.asInterface(binder) else null
            refresh()
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            service = null
            refresh()
        }
    }

    fun init(ctx: Context) {
        app = ctx.applicationContext
        Shizuku.addBinderReceivedListenerSticky(Shizuku.OnBinderReceivedListener { refresh() })
        Shizuku.addBinderDeadListener(Shizuku.OnBinderDeadListener {
            service = null
            refresh()
        })
        Shizuku.addRequestPermissionResultListener(Shizuku.OnRequestPermissionResultListener { _, _ -> refresh() })
        refresh()
    }

    fun refresh() {
        val ctx = app ?: return
        val alive = runCatching { Shizuku.pingBinder() }.getOrDefault(false)
        val granted = alive && runCatching {
            !Shizuku.isPreV11() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
        }.getOrDefault(false)
        val dump = ctx.checkSelfPermission(Manifest.permission.DUMP) == PackageManager.PERMISSION_GRANTED
        status.value = status.value.copy(
            running = alive,
            granted = granted,
            serviceConnected = service != null,
            dumpGranted = dump,
        )
        if (granted && service == null) bind()
    }

    fun requestPermission() {
        runCatching { Shizuku.requestPermission(1001) }
    }

    private fun bind() {
        val ctx = app ?: return
        runCatching {
            val args = Shizuku.UserServiceArgs(ComponentName(ctx.packageName, ShellService::class.java.name))
                .daemon(false)
                .processNameSuffix("shell")
                .debuggable(false)
                .version(1)
            Shizuku.bindUserService(args, conn)
        }
    }

    suspend fun exec(cmd: String): String? = withContext(Dispatchers.IO) {
        runCatching { service?.exec(cmd) }.getOrNull()
    }

    /** Grants everything the app can use extra: DUMP (session scan), notifications, no battery limits. */
    suspend fun grantAll(): String {
        val ctx = app ?: return "not ready"
        val p = ctx.packageName
        val steps = listOf(
            "DUMP permission" to "pm grant $p android.permission.DUMP",
            "Notifications" to "pm grant $p android.permission.POST_NOTIFICATIONS",
            "Battery whitelist" to "dumpsys deviceidle whitelist +$p",
            "Run in background" to "cmd appops set $p RUN_ANY_IN_BACKGROUND allow",
        )
        val sb = StringBuilder()
        for ((label, cmd) in steps) {
            val out = exec(cmd)
            val ok = out != null && !out.contains("Exception", true) && !out.startsWith("error")
            sb.appendLine((if (ok) "OK  " else "FAIL ") + label)
        }
        status.value = status.value.copy(log = sb.toString().trim())
        refresh()
        return sb.toString()
    }
}
