package com.stagesound.app.ui

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Equalizer
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import com.stagesound.app.data.SettingsStore

private data class Tab(val label: String, val icon: ImageVector)

@Composable
fun StageApp(store: SettingsStore) {
    val tabs = remember {
        listOf(
            Tab("Sound", Icons.Filled.GraphicEq),
            Tab("Equalizer", Icons.Filled.Equalizer),
            Tab("Engine", Icons.Filled.Bolt),
        )
    }
    var tab by rememberSaveable { mutableIntStateOf(0) }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.surface,
        bottomBar = {
            NavigationBar {
                tabs.forEachIndexed { i, t ->
                    NavigationBarItem(
                        selected = tab == i,
                        onClick = { tab = i },
                        icon = { Icon(t.icon, contentDescription = t.label) },
                        label = { Text(t.label) },
                    )
                }
            }
        },
    ) { inner ->
        Box(
            Modifier
                .fillMaxSize()
                .padding(inner)
                .statusBarsPadding(),
        ) {
            AnimatedContent(
                targetState = tab,
                transitionSpec = {
                    val dir = if (targetState > initialState) 1 else -1
                    (
                        fadeIn(spring(stiffness = Spring.StiffnessMediumLow)) +
                            slideInHorizontally(
                                spring(dampingRatio = Spring.DampingRatioLowBouncy, stiffness = Spring.StiffnessLow),
                            ) { dir * it / 4 } +
                            scaleIn(initialScale = 0.94f)
                        ) togetherWith (
                        fadeOut(spring(stiffness = Spring.StiffnessMedium)) +
                            slideOutHorizontally { -dir * it / 6 } +
                            scaleOut(targetScale = 0.96f)
                        )
                },
                label = "tabs",
            ) { page ->
                when (page) {
                    0 -> HomeScreen(store)
                    1 -> EqScreen(store)
                    else -> EngineScreen(store)
                }
            }
        }
    }
}
