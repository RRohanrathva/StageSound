package com.stagesound.app.engine

import android.content.Context
import com.stagesound.app.IShellService
import kotlin.system.exitProcess

/** Runs inside the Shizuku "shell" process, so commands here have shell (adb) privileges. */
class ShellService() : IShellService.Stub() {

    @Suppress("unused")
    constructor(context: Context) : this()

    override fun destroy() {
        exitProcess(0)
    }

    override fun exec(cmd: String): String {
        return try {
            val p = ProcessBuilder("sh", "-c", cmd).redirectErrorStream(true).start()
            val out = p.inputStream.bufferedReader().readText()
            p.waitFor()
            out
        } catch (t: Throwable) {
            "error: ${t.message}"
        }
    }
}
