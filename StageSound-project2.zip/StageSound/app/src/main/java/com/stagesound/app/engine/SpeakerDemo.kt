package com.stagesound.app.engine

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin

/**
 * 4 second stereo test: left speaker, right speaker, then a chord that sweeps left <-> right.
 * The demo track is attached to the engine, so you can switch the master toggle and hear the difference.
 */
object SpeakerDemo {
    private const val SR = 44100

    suspend fun play() = withContext(Dispatchers.IO) {
        val seconds = 4.2
        val n = (SR * seconds).toInt()
        val buf = ShortArray(n * 2)
        for (i in 0 until n) {
            val t = i.toDouble() / SR
            var l = 0.0
            var r = 0.0
            when {
                t < 0.7 -> l = tone(t, 440.0, t, 0.7)
                t < 1.4 -> r = tone(t - 0.7, 660.0, t - 0.7, 0.7)
                else -> {
                    val tt = t - 1.4
                    val s = tone(tt, 330.0, tt % 1.0, 1.0) + 0.6 * tone(tt, 495.0, tt % 1.0, 1.0)
                    val pan = (sin(2 * PI * tt / 2.8) + 1.0) / 2.0 // 0 left .. 1 right
                    l = s * (1.0 - pan)
                    r = s * pan
                }
            }
            buf[2 * i] = (l.coerceIn(-1.0, 1.0) * 14000).toInt().toShort()
            buf[2 * i + 1] = (r.coerceIn(-1.0, 1.0) * 14000).toInt().toShort()
        }

        val track = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build(),
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(SR)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_STEREO)
                    .build(),
            )
            .setBufferSizeInBytes(buf.size * 2)
            .setTransferMode(AudioTrack.MODE_STATIC)
            .build()

        val sid = track.audioSessionId
        EngineService.engine?.attach(sid, "Stage Sound demo", "DEMO")
        try {
            track.write(buf, 0, buf.size)
            track.play()
            delay((seconds * 1000).toLong() + 300)
        } finally {
            runCatching { track.stop() }
            track.release()
            EngineService.engine?.detach(sid)
        }
    }

    private fun tone(t: Double, hz: Double, local: Double, len: Double): Double {
        val env = exp(-2.2 * local / len) * (1.0 - exp(-60.0 * local))
        return env * (sin(2 * PI * hz * t) + 0.35 * sin(2 * PI * hz * 2 * t) + 0.15 * sin(2 * PI * hz * 3 * t)) * 0.6
    }
}
