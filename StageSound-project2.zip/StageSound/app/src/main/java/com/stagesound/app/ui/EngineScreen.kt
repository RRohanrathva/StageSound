package com.stagesound.app.ui

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Cancel
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Speaker
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.stagesound.app.data.EngineState
import com.stagesound.app.data.Mode
import com.stagesound.app.data.SettingsStore
import com.stagesound.app.engine.Capabilities
import com.stagesound.app.engine.ShizukuBridge
import kotlinx.coroutines.launch

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun EngineScreen(store: SettingsStore) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val s by store.flow.collectAsStateWithLifecycle()
    val sh by ShizukuBridge.status.collectAsStateWithLifecycle()
    val sessions by EngineState.sessions.collectAsStateWithLifecycle()
    val caps = remember { Capabilities.query() }

    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        item { Staggered(0) { Header("Engine", "Choose how the sound is processed") } }

        item {
            Staggered(1) {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    ModeCard(
                        title = "Normal mode",
                        body = "No special permission. Works with apps that share their audio session (YouTube Music, most music players) plus the system mix.",
                        selected = s.mode == Mode.NORMAL,
                    ) { store.update { it.copy(mode = Mode.NORMAL) } }
                    ModeCard(
                        title = "Shizuku mode (best quality)",
                        body = "Finds the audio session of EVERY app (YouTube, browsers, games) and attaches the full effect chain to each one. Needs Shizuku running.",
                        selected = s.mode == Mode.SHIZUKU,
                    ) { store.update { it.copy(mode = Mode.SHIZUKU) } }
                }
            }
        }

        item {
            Staggered(2) {
                SectionCard("Shizuku", Icons.Filled.Security) {
                    StatusRow("Shizuku is running", sh.running)
                    StatusRow("Permission granted to Stage Sound", sh.granted)
                    StatusRow("Shell service connected", sh.serviceConnected)
                    StatusRow("DUMP permission (all-app scan)", sh.dumpGranted)

                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        OutlinedButton(onClick = {
                            val i = ctx.packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")
                                ?: Intent(Intent.ACTION_VIEW, Uri.parse("https://github.com/RikkaApps/Shizuku/releases"))
                            runCatching { ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
                        }) {
                            Icon(Icons.Filled.OpenInNew, null, Modifier.size(18.dp))
                            Text("  Open Shizuku")
                        }
                        Button(
                            onClick = { ShizukuBridge.requestPermission() },
                            enabled = sh.running && !sh.granted,
                        ) { Text("Grant access") }
                        FilledTonalButton(
                            onClick = { scope.launch { ShizukuBridge.grantAll() } },
                            enabled = sh.granted && sh.serviceConnected,
                        ) { Text("Auto-setup") }
                        OutlinedButton(onClick = { ShizukuBridge.refresh() }) {
                            Icon(Icons.Filled.Refresh, null, Modifier.size(18.dp))
                            Text("  Refresh")
                        }
                    }
                    if (sh.log.isNotBlank()) {
                        Text(sh.log, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Text(
                        "Auto-setup grants the DUMP permission (to find every app's audio), notifications and battery exemption through Shizuku in one tap.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }

        item {
            Staggered(3) {
                SectionCard("Live sessions", Icons.Filled.Speaker) {
                    if (sessions.isEmpty()) {
                        Text(
                            "No audio session attached yet. Turn the engine on and start playing something.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }
        }
        items(sessions, key = { it.id }) { t ->
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer),
                modifier = Modifier
                    .fillMaxWidth()
                    .animateItem(),
            ) {
                Row(
                    Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    Icon(Icons.Filled.Bolt, null, tint = MaterialTheme.colorScheme.onSecondaryContainer)
                    Column(Modifier.weight(1f)) {
                        Text(t.pkg ?: "Session ${t.id}", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                        Text("id ${t.id} · ${t.source.lowercase()}", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }

        item {
            Staggered(4) {
                SectionCard("This phone supports", Icons.Filled.Memory) {
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        caps.forEach { (name, ok) ->
                            AssistChip(
                                onClick = {},
                                label = { Text(name) },
                                leadingIcon = {
                                    Icon(
                                        if (ok) Icons.Filled.CheckCircle else Icons.Filled.Cancel,
                                        null,
                                        Modifier.size(18.dp),
                                        tint = if (ok) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline,
                                    )
                                },
                            )
                        }
                    }
                }
            }
        }

        item {
            Staggered(5) {
                SectionCard("Behavior", Icons.Filled.Settings) {
                    SwitchRow("Include system mix (session 0)", "Tries to process everything; some phones ignore it", s.includeGlobal) { c ->
                        store.update { it.copy(includeGlobal = c) }
                    }
                    SwitchRow("Start after reboot", "Resumes the engine when the phone boots", s.autoStart) { c ->
                        store.update { it.copy(autoStart = c) }
                    }
                    Column {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Scan interval (Shizuku mode)", style = MaterialTheme.typography.titleMedium)
                            Text("${s.scanSeconds}s", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                        }
                        Slider(
                            value = s.scanSeconds.toFloat(),
                            onValueChange = { v -> store.update { it.copy(scanSeconds = v.toInt().coerceIn(1, 6)) } },
                            valueRange = 1f..6f,
                            steps = 4,
                        )
                    }
                }
            }
        }

        item {
            Staggered(6) {
                SectionCard("Keep it alive", Icons.Filled.BatteryChargingFull) {
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        if (Build.VERSION.SDK_INT >= 33) {
                            FilledTonalButton(onClick = { notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS) }) {
                                Icon(Icons.Filled.Notifications, null, Modifier.size(18.dp))
                                Text("  Notifications")
                            }
                        }
                        FilledTonalButton(onClick = {
                            val i = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:${ctx.packageName}"))
                            runCatching { ctx.startActivity(i) }
                        }) { Text("Battery: no limits") }
                        FilledTonalButton(onClick = {
                            val i = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${ctx.packageName}"))
                            runCatching { ctx.startActivity(i) }
                        }) { Text("App info (Autostart)") }
                        OutlinedButton(onClick = {
                            runCatching { ctx.startActivity(Intent(Settings.ACTION_SOUND_SETTINGS)) }
                        }) { Text("System sound settings") }
                    }
                    Text(
                        "On Xiaomi/Redmi (HyperOS) also enable Autostart for Stage Sound and set Battery saver to \"No restrictions\", otherwise the system may stop the engine in the background.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }

        item {
            Staggered(7) {
                SectionCard("About this sound", Icons.Filled.Info) {
                    Text(
                        "Stage Sound uses Android's built-in audio effects (virtualizer, bass, loudness, 10-band dynamics EQ and limiter) to widen the stereo image on both speakers. It is not the licensed Dolby Atmos decoder, so it can't create real Atmos; it gives an Atmos-style wide, spatial result. If your phone's own Dolby switch is on, turn it off while testing so the two effects don't fight.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }
    }
}

@Composable
private fun ModeCard(title: String, body: String, selected: Boolean, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val container by animateColorAsState(
        if (selected) cs.primaryContainer else cs.surfaceContainer,
        spring(stiffness = 300f),
        label = "modeBg",
    )
    val scale by animateFloatAsState(
        if (selected) 1f else 0.97f,
        spring(dampingRatio = 0.45f, stiffness = 350f),
        label = "modeScale",
    )
    Card(
        shape = RoundedCornerShape(28.dp),
        colors = CardDefaults.cardColors(containerColor = container),
        modifier = Modifier
            .fillMaxWidth()
            .scale(scale)
            .bouncyClick(onClick),
    ) {
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(
                    if (selected) Icons.Filled.CheckCircle else Icons.Filled.Bolt,
                    null,
                    tint = if (selected) cs.primary else cs.onSurfaceVariant,
                )
                Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            }
            Text(body, style = MaterialTheme.typography.bodyMedium, color = cs.onSurfaceVariant)
        }
    }
}

@Composable
private fun StatusRow(label: String, ok: Boolean) {
    val cs = MaterialTheme.colorScheme
    val tint by animateColorAsState(if (ok) cs.primary else cs.outline, spring(stiffness = 300f), label = "tint")
    val scale by animateFloatAsState(if (ok) 1f else 0.85f, spring(dampingRatio = 0.3f, stiffness = 400f), label = "sc")
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Icon(
            if (ok) Icons.Filled.CheckCircle else Icons.Filled.Cancel,
            null,
            tint = tint,
            modifier = Modifier.scale(scale),
        )
        Text(label, style = MaterialTheme.typography.bodyLarge)
    }
}

@Composable
private fun SwitchRow(title: String, sub: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f).padding(end = 12.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            Text(sub, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}
