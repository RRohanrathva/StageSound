package com.stagesound.app.engine

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.stagesound.app.StageApplication

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        val s = (context.applicationContext as StageApplication).store.flow.value
        if (s.enabled && s.autoStart) runCatching { EngineService.start(context) }
    }
}
