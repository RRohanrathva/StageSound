package com.stagesound.app.engine

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.media.audiofx.AudioEffect
import android.os.IBinder
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.stagesound.app.MainActivity
import com.stagesound.app.R
import com.stagesound.app.StageApplication
import com.stagesound.app.data.EngineState
import com.stagesound.app.data.Mode
import com.stagesound.app.data.SettingsStore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class EngineService : Service() {

    companion object {
        @Volatile
        var engine: AudioEngine? = null
        private const val CHANNEL = "engine"
        private const val NID = 7

        fun start(ctx: Context) {
            ContextCompat.startForegroundService(ctx, Intent(ctx, EngineService::class.java))
        }

        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, EngineService::class.java))
        }
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private lateinit var store: SettingsStore
    private lateinit var eng: AudioEngine

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            val id = intent.getIntExtra(AudioEffect.EXTRA_AUDIO_SESSION, -1)
            if (id < 0) return
            val pkg = intent.getStringExtra(AudioEffect.EXTRA_PACKAGE_NAME)
            val action = intent.action
            scope.launch {
                when (action) {
                    AudioEffect.ACTION_OPEN_AUDIO_EFFECT_CONTROL_SESSION -> eng.attach(id, pkg, "APP")
                    AudioEffect.ACTION_CLOSE_AUDIO_EFFECT_CONTROL_SESSION -> eng.detach(id)
                }
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        store = (application as StageApplication).store
        eng = AudioEngine()
        engine = eng
        EngineState.running.value = true

        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Sound engine", NotificationManager.IMPORTANCE_LOW),
        )
        ServiceCompat.startForeground(
            this, NID, buildNotification(0), ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE,
        )

        val filter = IntentFilter().apply {
            addAction(AudioEffect.ACTION_OPEN_AUDIO_EFFECT_CONTROL_SESSION)
            addAction(AudioEffect.ACTION_CLOSE_AUDIO_EFFECT_CONTROL_SESSION)
        }
        ContextCompat.registerReceiver(this, receiver, filter, ContextCompat.RECEIVER_EXPORTED)

        scope.launch {
            store.flow.collectLatest {
                delay(30)
                eng.apply(it)
            }
        }
        scope.launch {
            while (isActive) {
                val s = store.flow.value
                if (s.mode == Mode.SHIZUKU) {
                    val text = SessionScanner.dump(this@EngineService)
                    if (text != null) eng.syncScan(SessionScanner.parse(this@EngineService, text))
                } else {
                    eng.syncScan(emptyList())
                }
                delay(s.scanSeconds.coerceIn(1, 10) * 1000L)
            }
        }
        scope.launch {
            EngineState.sessions.collect { list ->
                val apps = list.count { it.id != 0 }
                nm.notify(NID, buildNotification(apps))
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        scope.cancel()
        runCatching { unregisterReceiver(receiver) }
        eng.releaseAll()
        engine = null
        EngineState.running.value = false
        EngineState.sessions.value = emptyList()
        super.onDestroy()
    }

    private fun buildNotification(apps: Int): Notification {
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE,
        )
        val text = if (apps > 0) "Spatial sound active on $apps app session(s)" else "Spatial sound engine running"
        return Notification.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle("Stage Sound")
            .setContentText(text)
            .setContentIntent(pi)
            .setOngoing(true)
            .build()
    }
}
