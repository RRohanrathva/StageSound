package com.stagesound.app

import android.app.Application
import com.stagesound.app.data.SettingsStore
import com.stagesound.app.engine.ShizukuBridge

class StageApplication : Application() {
    lateinit var store: SettingsStore
        private set

    override fun onCreate() {
        super.onCreate()
        store = SettingsStore(this)
        ShizukuBridge.init(this)
    }
}
