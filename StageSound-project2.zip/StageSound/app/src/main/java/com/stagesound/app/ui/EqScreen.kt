package com.stagesound.app.ui

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Equalizer
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.stagesound.app.data.EQ_LABELS
import com.stagesound.app.data.SettingsStore
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

private fun yToGain(y: Float, h: Float): Float {
    val raw = (0.5f - (y.coerceIn(0f, h) / h)) * 24f
    return raw.roundToInt().toFloat().coerceIn(-12f, 12f)
}

@Composable
fun EqScreen(store: SettingsStore) {
    val s by store.flow.collectAsStateWithLifecycle()

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        item { Staggered(0) { Header("Equalizer", "10 bands · ±12 dB · drag the bars") } }

        item {
            Staggered(1) {
                SectionCard("Response", Icons.Filled.Equalizer) {
                    EqCurve(s.eq, Modifier.fillMaxWidth().height(110.dp))
                }
            }
        }

        item {
            Staggered(2) {
                SectionCard("Bands") {
                    Row(
                        Modifier.fillMaxWidth().height(280.dp),
                        horizontalArrangement = Arrangement.spacedBy(2.dp),
                    ) {
                        s.eq.forEachIndexed { i, g ->
                            EqBand(
                                label = EQ_LABELS[i],
                                gain = g,
                                onChange = { v ->
                                    store.update { st ->
                                        val m = st.eq.toMutableList()
                                        m[i] = v
                                        st.copy(preset = "Custom", eq = m)
                                    }
                                },
                                modifier = Modifier.weight(1f).fillMaxHeight(),
                            )
                        }
                    }
                }
            }
        }

        item {
            Staggered(3) {
                FilledTonalButton(
                    onClick = { store.update { it.copy(preset = "Flat", eq = List(10) { 0f }) } },
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Icon(Icons.Filled.RestartAlt, null)
                    Text("  Reset equalizer")
                }
            }
        }
    }
}

@Composable
private fun EqBand(label: String, gain: Float, onChange: (Float) -> Unit, modifier: Modifier) {
    val cs = MaterialTheme.colorScheme
    val anim by animateFloatAsState(gain, spring(dampingRatio = 0.55f, stiffness = 600f), label = "gain")
    val cb by rememberUpdatedState(onChange)
    val track = cs.surfaceContainerHighest
    val fill = cs.primary
    val thumbInner = cs.onPrimary
    val tick = cs.outline

    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = (if (gain > 0) "+" else "") + gain.roundToInt(),
            style = MaterialTheme.typography.labelSmall,
            color = if (gain == 0f) cs.onSurfaceVariant else cs.primary,
        )
        Canvas(
            Modifier
                .weight(1f)
                .fillMaxWidth()
                .pointerInput(Unit) {
                    detectDragGestures(
                        onDragStart = { o -> cb(yToGain(o.y, size.height.toFloat())) },
                        onDrag = { change, _ ->
                            change.consume()
                            cb(yToGain(change.position.y, size.height.toFloat()))
                        },
                    )
                }
                .pointerInput(Unit) {
                    detectTapGestures(onTap = { o -> cb(yToGain(o.y, size.height.toFloat())) })
                },
        ) {
            val w = 12.dp.toPx()
            val cx = size.width / 2f
            val h = size.height
            drawRoundRect(
                color = track,
                topLeft = Offset(cx - w / 2f, 0f),
                size = Size(w, h),
                cornerRadius = CornerRadius(w / 2f),
            )
            val mid = h / 2f
            val y = h * (0.5f - anim / 24f)
            val top = min(y, mid)
            val bottom = max(y, mid)
            drawRoundRect(
                color = fill,
                topLeft = Offset(cx - w / 2f, top),
                size = Size(w, max(bottom - top, 2f)),
                cornerRadius = CornerRadius(w / 2f),
            )
            drawLine(tick, Offset(cx - w, mid), Offset(cx + w, mid), strokeWidth = 1.5.dp.toPx())
            drawCircle(fill, radius = 11.dp.toPx(), center = Offset(cx, y))
            drawCircle(thumbInner, radius = 4.dp.toPx(), center = Offset(cx, y))
        }
        Text(label, style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant)
    }
}

@Composable
private fun EqCurve(eq: List<Float>, modifier: Modifier) {
    val primary = MaterialTheme.colorScheme.primary
    val outline = MaterialTheme.colorScheme.outlineVariant
    val animated = eq.map { animateFloatAsState(it, spring(dampingRatio = 0.6f, stiffness = 400f), label = "c").value }

    Canvas(modifier) {
        val w = size.width
        val h = size.height
        drawLine(outline, Offset(0f, h / 2f), Offset(w, h / 2f), strokeWidth = 1.dp.toPx())
        val pts = animated.mapIndexed { i, g -> Offset(w * (i + 0.5f) / 10f, h * (0.5f - g / 24f)) }
        val line = Path().apply {
            moveTo(0f, pts[0].y)
            lineTo(pts[0].x, pts[0].y)
            for (i in 0 until 9) {
                val a = pts[i]
                val b = pts[i + 1]
                val mx = (a.x + b.x) / 2f
                cubicTo(mx, a.y, mx, b.y, b.x, b.y)
            }
            lineTo(w, pts[9].y)
        }
        val area = Path().apply {
            addPath(line)
            lineTo(w, h)
            lineTo(0f, h)
            close()
        }
        drawPath(area, Brush.verticalGradient(listOf(primary.copy(alpha = 0.35f), Color.Transparent)))
        drawPath(line, primary, style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round))
    }
}
