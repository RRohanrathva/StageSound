package com.stagesound.app.engine

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Finds the audio sessions of ALL running apps (YouTube, browsers, games...) by reading
 * "dumpsys audio". Needs the DUMP permission, which Shizuku can grant.
 */
object SessionScanner {
    private val sessRe = Regex("sessionId:(\\d+)")
    private val upidRe = Regex("u/pid:(\\d+)/(\\d+)")

    suspend fun dump(ctx: Context): String? = withContext(Dispatchers.IO) {
        if (ctx.checkSelfPermission(Manifest.permission.DUMP) == PackageManager.PERMISSION_GRANTED) {
            runCatching {
                val p = ProcessBuilder("dumpsys", "audio").redirectErrorStream(true).start()
                val t = p.inputStream.bufferedReader().readText()
                p.waitFor()
                t
            }.getOrNull()?.takeIf { it.isNotBlank() && !it.contains("Permission Denial") }
        } else {
            ShizukuBridge.exec("dumpsys audio")?.takeIf { it.isNotBlank() }
        }
    }

    fun parse(ctx: Context, text: String): List<Pair<Int, String?>> {
        val out = LinkedHashMap<Int, String?>()
        for (line in text.lineSequence()) {
            if (!line.contains("AudioPlaybackConfiguration")) continue
            val sid = sessRe.find(line)?.groupValues?.get(1)?.toIntOrNull() ?: continue
            if (sid <= 0) continue
            val uid = upidRe.find(line)?.groupValues?.get(1)?.toIntOrNull()
            val pkg = uid?.let { runCatching { ctx.packageManager.getPackagesForUid(it)?.firstOrNull() }.getOrNull() }
            if (pkg == ctx.packageName) continue
            out[sid] = pkg
        }
        return out.toList()
    }
}
