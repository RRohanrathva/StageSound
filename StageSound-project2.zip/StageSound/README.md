# Stage Sound

Atmos-style wide stereo for phone speakers (Kotlin + Jetpack Compose, Material 3 Expressive).

- Normal mode: audio effects on the system mix + apps that share their audio session.
- Shizuku mode: finds every app's audio session via `dumpsys audio` (DUMP permission, granted by Shizuku) and attaches the full chain.
- Effects: Virtualizer, Bass boost, Loudness, 10-band Dynamics EQ, Limiter, Balance.

Build: push this zip to GitHub together with `.github/workflows/build.yml`. The workflow unzips it and builds the APK.
